/** @module font.josefin */require( 'font.josefin', function(require, module, exports) { var _=function(){var D={"en":{},"fr":{}},X=require("$").intl;function _(){return X(D,arguments);}_.all=D;return _}();
    // Just an empty module to load Josefin Google's font.


  
module.exports._ = _;
/**
 * @module font.josefin
 * @see module:$

 */
});