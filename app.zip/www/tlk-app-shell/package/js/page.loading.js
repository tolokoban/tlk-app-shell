/** @module page.loading */require( 'page.loading', function(require, module, exports) { var _=function(){var D={"en":{},"fr":{}},X=require("$").intl;function _(){return X(D,arguments);}_.all=D;return _}();
    require("font.mystery-quest");

exports.onPage = function() {};


  
module.exports._ = _;
/**
 * @module page.loading
 * @see module:$
 * @see module:font.mystery-quest

 */
});