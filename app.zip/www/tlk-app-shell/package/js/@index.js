/**********************************************************************
 require( 'require' )
 -----------------------------------------------------------------------
 @example

 var Path = require("node://path");  // Only in NodeJS/NW.js environment.
 var Button = require("tfw.button");

 **********************************************************************/

window.require = function() {
    var modules = {};
    var definitions = {};
    var nodejs_require = typeof window.require === 'function' ? window.require : null;

    var f = function(id, body) {
        if( id.substr( 0, 7 ) == 'node://' ) {
            // Calling for a NodeJS module.
            if( !nodejs_require ) {
                throw Error( "[require] NodeJS is not available to load module `" + id + "`!" );
            }
            return nodejs_require( id.substr( 7 ) );
        }

        if( typeof body === 'function' ) {
            definitions[id] = body;
            return;
        }
        var mod;
        body = definitions[id];
        if (typeof body === 'undefined') {
            var err = new Error("Required module is missing: " + id);   
            console.error(err.stack);
            throw err;
        }
        mod = modules[id];
        if (typeof mod === 'undefined') {
            mod = {exports: {}};
            var exports = mod.exports;
            body(f, mod, exports);
            modules[id] = mod.exports;
            mod = mod.exports;
            //console.log("Module initialized: " + id);
        }
        return mod;
    };
    return f;
}();
function addListener(e,l) {
    if (window.addEventListener) {
        window.addEventListener(e,l,false);
    } else {
        window.attachEvent('on' + e, l);
    }
};

addListener(
    'DOMContentLoaded',
    function() {
        document.body.parentNode.$data = {};
        // Attach controllers.
        APP = require('app');
setTimeout(function (){if(typeof APP.start==='function')APP.start()});
var I = require('x-intl');
var W = require('x-widget');
        W('wdg.layout-stack5', 'wdg.layout-stack', {
            hash: "^#([a-zA-Z0-9]+)",
            content: [
          W({
              elem: "div",
              prop: {"$key": "Wait"},
              children: [
                "\n                ",
                                W('wdg.wait6', 'wdg.wait', {"size": "64px"}),
                "\n            "]}),
          W({
              elem: "div",
              attr: {
                key: "Home",
                class: "x-page"},
              prop: {"$key": "Home"},
              children: [
                W({
                  elem: "header",
                  attr: {"class": "theme-color-bg-B2"},
                  children: [W({
                      elem: "span",
                      attr: {
                        id: "_I1",
                        style: "display:none"}})]}),
                "\n\n",
                W({
                  elem: "div",
                  children: [
                    "\n    ",
                                        W('wdg.flex7', 'wdg.flex', {"content": [
                      W({
                          elem: "div",
                          attr: {"id": "search"}}),
                                              W('wdg.button8', 'wdg.button', {
                          text: "Nouveau patient",
                          icon: "add"})]}),
                    "\n    ",
                    W({
                      elem: "hr"}),
                    "\n    ",
                                        W('wdg.flex9', 'wdg.flex', {"content": [
                                              W('wdg.button10', 'wdg.button', {
                          text: "Exporter la base",
                          icon: "export"}),
                                              W('patients-count', 'wdg.button', {
                          type: "simple",
                          href: "#List"}),
                                              W('admin', 'wdg.button', {
                          text: "Administrateurs",
                          icon: "gear",
                          type: "warning"})]}),
                    "\n    ",
                    W({
                      elem: "hr"}),
                    "\n    ",
                    W({
                      elem: "div",
                      attr: {"id": "version"}}),
                    "\n"]}),
                "\n"]}),
          W({
              elem: "div",
              attr: {
                key: "List",
                class: "x-page"},
              prop: {"$key": "List"},
              children: [
                W({
                  elem: "header",
                  attr: {
                    id: "exam.title",
                    class: "theme-color-bg-B2"},
                  children: [
                    "\n    ",
                                        W('wdg.button11', 'wdg.button', {
                      text: "Retour",
                      icon: "back",
                      type: "simple",
                      href: "#Home"}),
                    "\n"]}),
                "\n\n",
                W({
                  elem: "div",
                  children: [
                    "\n    ",
                    W({
                      elem: "ul",
                      attr: {"id": "patients-list"}}),
                    "\n"]}),
                "\n"]}),
          W({
              elem: "div",
              attr: {
                key: "Patient",
                class: "x-page"},
              prop: {"$key": "Patient"},
              children: [
                W({
                  elem: "header",
                  attr: {"class": "theme-color-bg-B2"},
                  children: [
                    "\n    ",
                                        W('wdg.flex12', 'wdg.flex', {"content": [
                                              W('wdg.button13', 'wdg.button', {
                          text: "Retour",
                          icon: "back",
                          href: "#Home",
                          type: "simple"}),
                      W({
                          elem: "div",
                          attr: {"id": "patient.title"}})]}),
                    "\n"]}),
                "\n\n",
                W({
                  elem: "div",
                  children: [
                    "\n    ",
                                        W('wdg.flex14', 'wdg.flex', {"content": [
                      W({
                          elem: "div",
                          children: [
                            "\n                ",
                            W({
                              elem: "p",
                              attr: {
                                id: "patient.hint",
                                class: "theme-color-bg-B0"}}),
                            "\n                ",
                                                        W('patient.exit', 'wdg.button', {
                              text: "Sortie du patient",
                              icon: "close"}),
                            "\n                ",
                                                        W('wdg.button15', 'wdg.button', {
                              text: "Identité du patient",
                              icon: "user"}),
                            "\n                ",
                                                        W('wdg.button16', 'wdg.button', {
                              text: "Créer une nouvelle visite",
                              icon: "plus"}),
                            "\n                ",
                                                        W('wdg.button17', 'wdg.button', {
                              text: "Prescrire des examens",
                              icon: "print"}),
                            "\n            "]}),
                                              W('picture', 'picture', {})]}),
                    "\n    ",
                    W({
                      elem: "hr"}),
                    "\n    ",
                                        W('wdg.showhide18', 'wdg.showhide', {
                      label: "Pièces jointes",
                      value: "false",
                      content: [
                                              W('wdg.button19', 'wdg.button', {
                          text: "Ajouter une pièce jointe au dossier",
                          icon: "add"}),
                      W({
                          elem: "div",
                          attr: {"id": "attachments"}})]}),
                    "\n    ",
                                        W('wdg.showhide20', 'wdg.showhide', {
                      label: "Liste des vaccins",
                      value: "false",
                      content: [
                      W({
                          elem: "div",
                          attr: {"id": "vaccins"}})]}),
                    "\n    ",
                    W({
                      elem: "hr"}),
                    "\n    ",
                                        W('wdg.flex21', 'wdg.flex', {"content": [
                                              W('wdg.button22', 'wdg.button', {
                          text: "Retour à l'écran principal",
                          icon: "back",
                          href: "#Home",
                          type: "simple"})]}),
                    "\n    ",
                                        W('vaccin-edit', 'wdg.modal', {
                      visible: "false",
                      padding: "true",
                      content: [
                      W({
                          elem: "h1",
                          attr: {"id": "vaccin-name"}}),
                      W({
                          elem: "center",
                          children: [
                            "\n                ",
                                                        W('vaccin-date', 'wdg.date2', {"label": "Date de la dernière vaccination"}),
                            "\n                ",
                                                        W('vaccin-lot', 'wdg.text', {
                              label: "Numéro de lot",
                              wide: "true"}),
                            "\n                ",
                            W({
                              elem: "div",
                              attr: {
                                class: "x-spc H",
                                style: "height:2rem"}}),
                            "\n                ",
                                                        W('wdg.flex23', 'wdg.flex', {"content": [
                                                              W('btnVaccinCancel', 'wdg.button', {
                                  icon: "cancel",
                                  text: "Annuler",
                                  type: "simple",
                                  value: "false"}),
                                                              W('wdg.button24', 'wdg.button', {
                                  text: "Valider",
                                  icon: "ok"})]}),
                            "\n                ",
                            W({
                              elem: "hr"}),
                            "\n                ",
                                                        W('wdg.button25', 'wdg.button', {
                              text: "Supprimer la date",
                              type: "warning",
                              icon: "delete"}),
                            "\n            "]})]}),
                    "\n"]}),
                "\n"]}),
          W({
              elem: "div",
              attr: {
                key: "Visit",
                class: "x-page"},
              prop: {"$key": "Visit"},
              children: [
                W({
                  elem: "header",
                  attr: {"class": "theme-color-bg-B2"},
                  children: [
                    "\n    ",
                                        W('wdg.flex26', 'wdg.flex', {"content": [
                                              W('wdg.button27', 'wdg.button', {
                          text: "Retour",
                          type: "simple",
                          icon: "back"}),
                      W({
                          elem: "div",
                          attr: {"id": "visit.title"}})]}),
                    "\n"]}),
                "\n\n",
                W({
                  elem: "div",
                  children: [
                    "\n    ",
                    W({
                      elem: "div",
                      attr: {"id": "visit.data"}}),
                    "\n    ",
                    W({
                      elem: "hr"}),
                    "\n    ",
                    W({
                      elem: "center",
                      children: [
                        "\n        ",
                                                W('wdg.button28', 'wdg.button', {
                          text: "Terminer la rencontre",
                          icon: "ok"}),
                        "\n    "]}),
                    "\n"]}),
                "\n"]}),
          W({
              elem: "div",
              attr: {
                key: "Exam",
                class: "x-page"},
              prop: {"$key": "Exam"},
              children: [
                W({
                  elem: "header",
                  attr: {
                    id: "exam.title",
                    class: "theme-color-bg-B2"},
                  children: [
                    "\n    ",
                                        W('exam.back', 'wdg.button', {
                      text: "Retour",
                      icon: "back",
                      type: "simple"}),
                    "\n"]}),
                "\n\n",
                W({
                  elem: "div",
                  children: [
                    "\n    ",
                    W({
                      elem: "div",
                      attr: {"id": "exam.data"}}),
                    "\n    ",
                    W({
                      elem: "hr"}),
                    "\n    ",
                    W({
                      elem: "center",
                      children: [
                        "\n        ",
                                                W('wdg.button29', 'wdg.button', {
                          text: "Préparer le document pour impression",
                          icon: "print"}),
                        "        \n    "]}),
                    "\n"]}),
                "\n"]})]})
        W.bind('wdg.layout-stack5',{"value":{"S":["onPage"]}});
I(1,"title-home")
        W.bind('wdg.button8',{"action":{"S":[["page.home","onNewPatient"]]}});
        W.bind('wdg.button10',{"action":{"S":[["page.home","onExport"]]}});
        W.bind('admin',{"action":{"S":[["page.home","onAdmin"]]}});
        W.bind('patient.exit',{"action":{"S":[["page.patient","onPatientExit"]]}});
        W.bind('wdg.button15',{"action":{"S":[["page.patient","onPatientEdit"]]}});
        W.bind('wdg.button16',{"action":{"S":[["page.patient","onNewVisit"]]}});
        W.bind('wdg.button17',{"action":{"S":[["page.patient","onExam"]]}});
        W.bind('wdg.button19',{"action":{"S":[["page.patient","onAddAttachment"]]}});
        W.bind('vaccin-edit',{"visible":{"B":[["btnVaccinCancel","action"]]}});
        W.bind('wdg.button24',{"action":{"B":[["vaccin-lot","action"]],"S":[["page.patient","onVaccinOK"]]}});
        W.bind('wdg.button25',{"action":{"S":[["page.patient","onVaccinDel"]]}});
        W.bind('wdg.button27',{"action":{"S":[["page.visit","onBack"]]}});
        W.bind('wdg.button28',{"action":{"S":[["page.visit","onClose"]]}});
        W.bind('exam.back',{"action":{"S":[["page.exam","onBack"]]}});
        W.bind('wdg.button29',{"action":{"S":[["page.exam","onPrint"]]}});
    }
);
