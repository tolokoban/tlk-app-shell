/** @module font.mystery-quest */require( 'font.mystery-quest', function(require, module, exports) { var _=function(){var D={"en":{},"fr":{}},X=require("$").intl;function _(){return X(D,arguments);}_.all=D;return _}();
    // Container for Google's font Mytery Quest.


  
module.exports._ = _;
/**
 * @module font.mystery-quest
 * @see module:$

 */
});